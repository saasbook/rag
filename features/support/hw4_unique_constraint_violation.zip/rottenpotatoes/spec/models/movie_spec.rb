require 'rails_helper'

describe Movie do
    describe 'finding movie list with same director as Star Wars' do
        before :each do
            @movie = FactoryGirl.create(:movie, :title => 'Star Wars',
              :director => 'George Lucas', :id => '1')
            @movie2 = FactoryGirl.create(:movie, :title => 'Blade Runner', :director => 'Ridley Scott')
            @movie3 = FactoryGirl.create(:movie, :title => 'Alien', :director => '')
            @movie4 = FactoryGirl.create(:movie, :title => 'THX-1138', :director => 'George Lucas')
        end
        it 'should return list of movies with same director' do
            expect(Movie.same_director_list(@movie.id)).to match_array(Movie.where(title: 'THX-1138')) 
        end
        
        it 'should not return movies with a different director' do
            expect(Movie.same_director_list(@movie.id)).to_not match_array(Movie.where(title:
              ['Star Wars', 'Blade Runner', 'Alien']))
        end

    end
end