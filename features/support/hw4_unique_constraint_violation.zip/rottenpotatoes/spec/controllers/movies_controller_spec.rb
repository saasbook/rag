require 'rails_helper'

describe MoviesController do
    describe 'find_same_director' do
        before :each do
            @fake_results = [double('movie1'), double('movie2')]
            @fake_movie = double('movie3', :director => 'George Lucas')
        end
        it 'calls the model method that returns movies with same director' do
            expect(Movie).to receive(:same_director_list).with('1').
              and_return(@fake_results)
            allow(Movie).to receive(:find).with('1').and_return(@fake_movie)
            allow(@fake_movie).to receive(:director).with('1').and_return('George Lucas')
            post :find_same_director, {:id => '1'}
        end
        it 'calls the model method that finds the movie with id' do
            allow(Movie).to receive(:same_director_list).with('1').
              and_return(@fake_results)
            expect(Movie).to receive(:find).with('1').and_return(@fake_movie)
            allow(@fake_movie).to receive(:director).with('1').and_return('George Lucas')
            post :find_same_director, {:id => '1'}            
        end
        describe 'after valid find' do
            before :each do
                allow(@fake_movie).to receive(:director).and_return('George Lucas')
                allow(Movie).to receive(:same_director_list).with('1').
                  and_return(@fake_results)
                allow(Movie).to receive(:find).with('1').and_return(@fake_movie)
                post :find_same_director, {id: '1'}
            end
            it 'selects the Similar Director List template for rendering' do
                expect(response).to render_template('find_same_director')
            end
            it 'makes the find_same_director and find results available to that template' do
                expect(assigns(:movies)).to eq(@fake_results)
                expect(assigns(:movie)).to eq(@fake_movie)
            end
        end
        describe 'after movie with no director' do
            it 'selects the home page template to render' do
                fake_movie2 = double('movie4', :director => '', :id => '3', :title => 'Alien')
                allow(fake_movie2).to receive(:director).and_return('')
                allow(Movie).to receive(:same_director_list).with('3').
                  and_return([])
                allow(Movie).to receive(:find).with('3').and_return(fake_movie2)
                post :find_same_director, {id: '3'}
                expect(response).to redirect_to(:controller => 'movies', :action => 'index')
            end
        end
    end
    
    describe 'update' do
        it 'calls the model instance method find' do
            fake_movie = double('movie', :title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            expect(Movie).to receive(:find).with('1').and_return(fake_movie)
            allow(fake_movie).to receive(:update_attributes!).with(:title => 'Star Wars')
            post :update, {id: '1', movie: {:title => 'Star Wars'}}
        end
        it 'calls the model instance method update_attributes and updates' do
            fake_movie = Movie.new( :title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            fake_movie_update = Movie.new( :title => 'A Fake Title', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            allow(Movie).to receive(:find).with('1').and_return(fake_movie)
            expect(fake_movie).to receive(:update_attributes!).
                with(:title => 'A Fake Title', :rating => 'PG', 
                :director => 'George Lucas').and_return(fake_movie_update)
            post :update, {id: '1', movie: {:title => 'A Fake Title', 
                :id => '1', :rating => 'PG', :director => 'George Lucas'}}  
            expect(assigns(:movie)).to eq fake_movie_update
        end
        it 'selects the details page template via redirect to render' do
            fake_movie = Movie.new( :title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            fake_movie_update = Movie.new( :title => 'A Fake Title', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            allow(Movie).to receive(:find).with('1').and_return(fake_movie)
            allow(fake_movie).to receive(:update_attributes!).
                with(:title => 'A Fake Title', :rating => 'PG', 
                :director => 'George Lucas').and_return(fake_movie_update)
            post :update, {id: '1', movie: {:title => 'A Fake Title', 
                :id => '1', :rating => 'PG', :director => 'George Lucas'}} 
            expect(response).to redirect_to(:controller => 'movies', :action => 'show', :id => '1')
        end
    end
    describe 'create' do
        it 'calls the model instance method creat' do
            fake_movie = double('movie', :title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            expect(Movie).to receive(:create!).with(:title => 'Star Wars', 
                :rating => 'PG', :director => 'George Lucas').and_return(fake_movie)
            post :create, {id: '1', movie: {:title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas'}}
        end
        it 'selects the home page template via redirect to render' do
            fake_movie = double('movie', :title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas')
            allow(Movie).to receive(:create!).with(:title => 'Star Wars', 
                :rating => 'PG', :director => 'George Lucas').and_return(fake_movie)
            post :create, {id: '1', movie: {:title => 'Star Wars', 
                :id => '1', :rating => 'PG', :director => 'George Lucas'}}
            expect(response).to redirect_to(:controller => 'movies', :action => 'index')
        end
    end
    
    describe 'destroy' do
        it 'calls the model method find' do
            fake_movie = double('movie', :title => 'Star Wars', :id => '1',
                :rating => 'PG', :director => 'George Lucas')
            expect(Movie).to receive(:find).with('1').and_return(fake_movie)
            allow(fake_movie).to receive(:destroy)
            delete :destroy, :id => '1'
        end
        it 'selects the home page template via redirect to render' do
            fake_movie = double('movie', :title => 'Star Wars', :id => '1',
                :rating => 'PG', :director => 'George Lucas')
            allow(Movie).to receive(:find).with('1').and_return(fake_movie)
            allow(fake_movie).to receive(:destroy)
            delete :destroy, :id => '1'
        end
    end
end