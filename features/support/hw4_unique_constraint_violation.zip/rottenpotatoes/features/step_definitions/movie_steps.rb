# Add a declarative step here for populating the DB with movies.

Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    Movie.create!(movie)
    # each returned element will be a hash whose key is the table header.
    # you should arrange to add that movie to the database here.
  end
end

Then /the (.*) of "(.*)" should be "(.*)"/ do |attribute, title, value|
    
    details = page.all('ul li')
    case attribute
    
    when "rating"
        index = 0
    when "director"
        index = 2
    when "release date"
        index = 1
    end
    
    expect(details[index].text.match(/.*:\s(.*)/)[1]).to eq value
    expect(page.find('h2').text.match(/Details about (.*)/)[1]).to eq title
        
end