
# Add a declarative step here for populating the DB with movies.
Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    Movie.create!(movie)
    # each returned element will be a hash whose key is the table header.
    # you should arrange to add that movie to the database here.
  end
end
  
# Make sure that a string (rex) occurs before or after another on the same page
Then /I should see "(.*)" before "(.*)"/ do |e1, e2|
  #  ensure that that e1 occurs before e2.
  #  page.body is the entire content of the page as a string.
  expect(page.body).to match(/.*#{e1}.*#{e2}/m)
end

# Make it easier to express checking or unchecking several boxes at once
#  "When I uncheck the following ratings: PG, G, R"
#  "When I check the following ratings: G"
# As well as all of them
When /I (un)?check (the following|all of the) ratings:? ?(.*)/ do |uncheck, which, ratings_str|
  # HINT: use String#split to split up the rating_list, then
  #   iterate over the ratings and reuse the "When I check..." or
  which.include?('all') ? ratings = Movie.all_ratings : ratings = ratings_str.split
  ratings.each do |rating|  
    #   "When I uncheck..." steps in lines 89-95 of web_steps.rb
    step %Q{I #{uncheck}check "ratings[#{rating}]"}
  end
end

Then /^I should (not )?see (the following|all of the) movies:?\s*(.*)$/ do |negated, which, movies_str|
  which.include?('all') ? movie_titles = Movie.all.map{|movie| movie.title} : movie_titles = movies_str.split(/,\s*/)
  movie_titles.each do |title|
    step %Q{I should #{negated}see "More about #{title}"} #assurance movie is found in title field
  end
end

Then /^the ([^ ]*) of "([^"]*)" should be "([^"]*)"$/ do |field, title, field_value|
  expect(page.body).to match(/.*Details about #{title}.*#{field.capitalize}:.*#{field_value}/m)
end

Then /^(\d+) seed movies should exist$/ do | n_seeds |
  #byebug
  expect(Movie.count).to eq(n_seeds.to_i)
  #p Movie.count
  #p n_seeds.to_i
  #byebug
end