require 'rails_helper'
 
describe MoviesController do
  describe 'find similar movies by director' do
    context 'the movie has a director' do
      it 'should call the model method that finds movies by the same director' do 
        expect(Movie).to receive(:find_movies_same_director).with('Star Wars')
        get :similar, {:id => 'Star Wars'}
      end
      it 'should select the similar movies template for rendering' do
        allow(Movie).to receive(:find_movies_same_director)
        get :similar, {:id => 'Star Wars'}
        expect(response).to render_template('similar')
      end
      it 'should make the list of movies by the same director available to that template' do
        some_movies = [double('Movie'), double('Movie')]
        allow(Movie).to receive(:find_movies_same_director).and_return(some_movies)
        get :similar, {:id => 'Star Wars'}
        # look for controller method to assign @movies
        expect(assigns(:movies)).to eq(some_movies)
      end       
    end
    context 'the movie has no director' do
      it 'should redirect to show' do
        no_director = double('Movie', title: 'no director')
        allow(Movie).to receive(:find_movies_same_director).and_raise(ArgumentError)
        allow(Movie).to receive(:find).and_return(no_director)
        get :similar, {:id => 'No director'}
        expect(response).to redirect_to(movies_path)
      end
      it 'should display an error message' do
        no_director = double('Movie', title: 'no director')
        allow(Movie).to receive(:find_movies_same_director).and_raise(ArgumentError)
        allow(Movie).to receive(:find).and_return(no_director)
        get :similar, {:id => 'No director'}
        expect(flash[:warning]).to eq("'no director' has no director info")
      end       
    end
  end
end

