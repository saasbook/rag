Given /^I am on the RottenPotatoes home page$/ do
  visit movies_path
 end


 When /^I have added a movie with title "(.*?)" and rating "(.*?)"$/ do |title, rating|
  visit new_movie_path
  fill_in 'Title', :with => title
  select rating, :from => 'Rating'
  click_button 'Save Changes'
 end

 Then /^I should see a movie list entry with title "(.*?)" and rating "(.*?)"$/ do |title, rating| 
   result=false
   all("tr").each do |tr|
     if tr.has_content?(title) && tr.has_content?(rating)
       result = true
       break
     end
   end  
   assert result
 end

 When /^I have visited the Details about "(.*?)" page$/ do |title|
   visit movies_path
   click_on "More about #{title}"
 end

Then /^(?:|I )should see "([^"]*)"$/ do |text|
  if page.respond_to? :should
    page.should have_content(text)
  else
    assert page.has_content?(text)
  end
end

 When /^I have edited the movie "(.*?)" to change the rating to "(.*?)"$/ do |movie, rating|
  click_on "Edit"
  select rating, :from => 'Rating'
  click_button 'Update Movie Info'
 end


# New step definitions to be completed for HW3. 
# Note that you may need to add additional step definitions beyond these


# Add a declarative step here for populating the DB with movies.

Given /the following movies have been added to RottenPotatoes:/ do |movies_table|
	@count = 0
  movies_table.hashes.each do |movie|
    # Each returned movie will be a hash representing one row of the movies_table
    # The keys will be the table headers and the values will be the row contents.
    # You should arrange to add that movie to the database here.
    # You can add the entries directly to the databasse with ActiveRecord methodsQ
		Movie.create!(movie)
		@count = @count+1	
  end
end

When /^I have opted to see movies rated: "(.*?)"$/ do |arg1|
  # HINT: use String#split to split up the rating_list, then
  # iterate over the ratings and check/uncheck the ratings
  # using the appropriate Capybara command(s)
	Movie.all_ratings.to_a.each do |everyRating|
		uncheck "ratings[#{everyRating}]"
	end
	arg1.split(", ").each do |myRatings|
		check "ratings[#{myRatings}]"
	end
	click_button('Refresh')
end

Then /^I should see only movies rated "(.*?)"$/ do |arg1|
	arg1.split(", ").each do |yesRatings|
		if page.has_no_css?('td', :text => /\A#{yesRatings}\z/)			
			assert false, "Assert failed: #{yesRatings} is a rating you should see."
		end
 	end 
	arg2 = Movie.all_ratings.to_a - arg1.split(", ")
	arg2.each do |noRatings|
		if page.has_css?('td', :text => /\A#{noRatings}\z/)			
			assert false, "Assert failed: #{noRatings} is not a rating you should see."
		end
 	end 
end

Then /^I should see all of the movies$/ do
	allMovies = 0
	all("td").each do |td|
		allMovies = allMovies+1
	end
	 assert allMovies/4 == @count, "Assert failed: Not all movies are displayed."	
end

When /^I select to display movies in alphabetical order$/ do
	if find_link('Movie Title').visible?
		click_link('Movie Title')
	else
		assert false, "Assert failed: Link does not exist"
	end
end

When /^I select to display movies by release date$/ do
	if find_link('Release Date').visible?
		click_link('Release Date')
	else
		assert false, "Assert failed: Link does not exist"
	end
end

Then /^I should see "(.*?)" before "(.*?)"$/ do |movie1, movie2|
	result = 0
	if page.has_no_css?('td', :text => /\A#{movie1}\z/) || page.has_no_css?('td', :text => /\A#{movie1}\z/)		
		assert false, "Assert failed: movies are not set up correctly."
	end	
	all("td").each do |td|
		result = 1 if td.has_content?("#{movie1}") && result == 0
		result = 2 if td.has_content?("#{movie2}") && result == 0
	end
	assert result == 1, "Assret failed: #{movie1} is not found before #{movie2}."
end