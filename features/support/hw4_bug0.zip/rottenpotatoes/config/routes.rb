Rottenpotatoes::Application.routes.draw do
  resources :movies
  
  match '/movies/:id/director', to: 'movies#same_director', :via => [:get], :as => :same_director
  
  # map '/' to be a redirect to '/movies'
  root :to => redirect('/movies')
end