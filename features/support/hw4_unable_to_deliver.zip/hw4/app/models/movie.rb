class Movie < ActiveRecord::Base
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end
  
  def find_similar_by_director
    if self.director == nil or self.director == ''
      return []
    else
      return Movie.where(director: self.director)
    end
  end
  
end
