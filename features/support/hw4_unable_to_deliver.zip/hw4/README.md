THIS REPOSITORY IS DEPRECATED AND WILL SOON BE DELETED.  DO NOT USE IT.
=======================================================================

Prior to September 2013, this code was used in UC Berkeley CS169 and/or
BerkeleyX CS169.1x/.2x on edX.

Effective September 2013, we are revising, refactoring and improving the
homeworks and autograders.  THEREFORE:

* The code in this repo may not work as described in the course, or at
all.

* We will be ignoring pull requests to this repo until it is deleted.

* We will not be answering ANY questions related to this repo.  It is a
non-repo for us.  We have disowned it.  It does not exist.  It has never
existed.

* We will silently ignore all inquiries related to this repo r to any
forks or clones of it.

* You will not get any kind of partial credit in the course if your
homework has errors due to differences between the code in this repo and
the code used in the course.  We will not help you debug homework
problems arising from the use of obsolete materials such as the contents of
this repo.

We will distribute homework "skeleton" code along with each homework
that has been tested with the current autograders.  That code, and ONLY
that code, should be used as the basis of your homework assignments.

Thanks - the CS169 course authors
