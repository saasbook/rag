require 'rails_helper'

RSpec.describe MoviesController, :type => :controller do

  describe "GET #similar_movies" do
    before(:each) do
          @fake_results = [double("Movie1", director: "MyDirector"), double("Movie2", director: "MyDirector")]
          @movie_with_director = double("Movie", find_similar_by_director: @fake_results, id: "1", director: "MyDirector", title: "Star Wars", release_date: "1977-05-25", rating: "PG", description: "Star wars description goes here")
          allow(Movie).to receive(:find).with("1").and_return(@movie_with_director)
          
          @movie_with_no_director = double("Movie", find_similar_by_director: [], id: "2", director: "", title: "MyTitle", release_date: "1994-05-25", rating: "PG", description: "MyTitle description goes here")
          allow(Movie).to receive(:find).with("2").and_return(@movie_with_no_director)
    end
    
    it "should return movies when a director is specified" do
        #expect(@movie_with_director).to receive(:find_similar_by_director).and_return(@fake_results)
        get :similar_movies, {id: @movie_with_director.id}
        expect(response).to render_template(:similar_movies)
        expect(assigns[:similar_movies]).to match_array(@fake_results)

    end

    it "should not return movies when a director is not specified" do
        get :similar_movies, {id: @movie_with_no_director.id}
        expect(flash[:notice]).to eq("'#{@movie_with_no_director.title}' has no director info")
        expect(response).to redirect_to(movies_path)
    end
    
  end #end of similar_movies describe block

  describe "POST #create" do
      it "should create a new movie in the database, set the flash, and redirect to movies path" do
        movie_title = "My New Movie"
        post :create, :movie => {:title => movie_title, :rating => 'PG', :description => 'my description', :release_date => '1977-05-25', :director => 'George Lucas'}
        expect(assigns(:movie)).not_to be_nil
        expect(flash[:notice]).to eq("#{movie_title} was successfully created.")
        expect(response).to redirect_to(movies_path)
      end
  end
  
  describe "DELETE #destroy" do
    before(:each) do
      @movie = FactoryGirl.create(:movie)
    end
    
    it "should delete a movie with the given id in the database, set the flash, and redirect to movies path" do
        delete :destroy, :id => @movie.id
        expect(Movie.exists?(@movie.id)).to be_falsy
        expect(flash[:notice]).to eq("Movie '#{@movie.title}' deleted.")
        expect(response).to redirect_to(movies_path)
    end
  end

  describe "GET #index" do
    before(:each) do
      @ratings = {'G' => 'G', 'PG' => 'PG', 'PG-13' => 'PG-13', 'NC-17' => 'NC-17', 'R' => 'R'}
      movie_1_attrs = FactoryGirl.attributes_for :movie
      movie_2_attrs = FactoryGirl.attributes_for :movie
      movie_3_attrs = FactoryGirl.attributes_for :movie
      movie_4_attrs = FactoryGirl.attributes_for :movie
      movie_5_attrs = FactoryGirl.attributes_for :movie
      
      movie_1_attrs["title"] = 'Star Wars'
      movie_1_attrs["rating"] = 'PG'
      movie_1_attrs["release_date"] = '1977-05-25'
      movie_1_attrs["director"] = 'George Lucas'
      movie_1_attrs["description"] = 'Star Wars is a movie about...'
      
      movie_2_attrs["title"] = 'Blade Runner'
      movie_2_attrs["rating"] = 'PG'
      movie_2_attrs["release_date"] = '1982-06-25'
      movie_2_attrs["director"] = 'Ridley Scott'
      movie_2_attrs["description"] = 'Blade Runner is a movie about...'

      movie_3_attrs["title"] = 'Alien'
      movie_3_attrs["rating"] = 'R'
      movie_3_attrs["release_date"] = '1979-05-25'
      movie_3_attrs["director"] = 'Ridley Scott'
      movie_3_attrs["description"] = '.........'

      movie_4_attrs["title"] = 'THX-1138'
      movie_4_attrs["rating"] = 'R'
      movie_4_attrs["release_date"] = '1971-03-11'
      movie_4_attrs["director"] = 'George Lucas'
      movie_4_attrs["description"] = 'THX is a movie about'
 
      movie_5_attrs["title"] = 'Superman'
      movie_5_attrs["rating"] = 'PG'
      movie_5_attrs["release_date"] = '1973-03-21'
      movie_5_attrs["director"] = ''
      movie_5_attrs["description"] = 'Superman is a movie about'
    
      @movie_1 = FactoryGirl.create(:movie, movie_1_attrs)
      @movie_2 = FactoryGirl.create(:movie, movie_2_attrs)
      @movie_3 = FactoryGirl.create(:movie, movie_3_attrs)
      @movie_4 = FactoryGirl.create(:movie, movie_4_attrs)
      @movie_5 = FactoryGirl.create(:movie, movie_5_attrs)
      
      allow(Movie).to receive(:order).with(:title).and_return([@movie_3, @movie_2, @movie_1, @movie_5, @movie_4])
      allow(Movie).to receive(:order).with(:release_date).and_return([@movie_4, @movie_5, @movie_1, @movie_3, @movie_2])
      
    end
      
    it "should sort movies by title" do
      get :index, {:sort => 'title', :ratings => @ratings}, {:sort => 'title', :ratings => @ratings}
      expect(assigns(:title_header)).to eq('hilite')

      expect(assigns(:movies)).to match_array(Movie.order(:title))
      
    end
    
    it "should sort movies by rating" do
      get :index, {:sort => 'release_date', :ratings => @ratings}, {:sort => 'release_date', :ratings => @ratings}
      expect(assigns(:date_header)).to eq('hilite')
      expect(assigns(:movies)).to match_array(Movie.order(:release_date))
    end
    
    it "should redirect when params[:sort] and session[:sort] do not match" do
        get :index, {:sort => 'title', :ratings => @ratings}, {:sort => 'release_date', :ratings => @ratings}
        expect(session[:sort]).to eq("title")
        expect(session[:ratings]).to eq(@ratings)
        expect(response).to redirect_to(movies_path(:sort => 'title', :ratings => {'G' => 'G', 'PG' => 'PG', 'PG-13' => 'PG-13', 'NC-17' => 'NC-17', 'R' => 'R'}))
    end
  
    it "should redirect when params[:ratings] and session[:ratings] do not match" do
        get :index, {:sort => 'title', :ratings => @ratings}, {:sort => 'title', :ratings => {'G' => 'G', 'PG' => 'PG', 'PG-13' => 'PG-13', 'NC-17' => 'NC-17'}}
        expect(session[:sort]).to eq("title")
        expect(session[:ratings]).to eq(@ratings)
        expect(response).to redirect_to(movies_path(:sort => 'title', :ratings => @ratings))
    end
    
    it "should default to Movie.all_ratings when no ratings are in params or the session" do
      get :index, {:sort => 'title'}
      expect(assigns[:selected_ratings]).to match_array(@ratings)
    end
    
  end
  
  describe "GET #show" do
    before(:each) do
      @movie = FactoryGirl.create(:movie)
    end
    
    it "should display the movies attributes" do
      get :show, {:id => @movie.id}
      expect(assigns[:movie].title).to eq(@movie.title)
      expect(assigns[:movie].rating).to eq(@movie.rating)
      expect(assigns[:movie].director).to eq(@movie.director)
    end
  
  end
  
  describe "PATCH #update" do
    before(:each) do
      @movie = FactoryGirl.create(:movie)
    end
    
    it "should update an attribute for an existing object" do
        patch :update, :id => @movie.id, :movie => {:rating => 'R'}
        expect(Movie.find(@movie.id).rating).to eq('R')
        expect(flash[:notice]).to eq("#{@movie.title} was successfully updated.")
        expect(response).to redirect_to(movie_path(@movie))
    end
  end
  
  describe "GET #edit" do
    before(:each) do
      @movie = FactoryGirl.create(:movie)
    end
    
    it "should render the edit page" do
      get :edit, :id => @movie.id
      expect(response).to render_template(:edit)
      expect(assigns[:movie].title).to eq(@movie.title)
      expect(assigns[:movie].rating).to eq(@movie.rating)
      expect(assigns[:movie].director).to eq(@movie.director)
    end
  end
  
  describe "GET #new" do

    it "should render the new template" do
      get :new
      expect(response).to render_template(:new)
    end
  end
  
end