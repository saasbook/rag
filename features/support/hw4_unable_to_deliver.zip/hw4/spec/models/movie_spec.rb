require 'rails_helper'

RSpec.describe Movie, :type => :model do
  
  describe "#find_similar_by_director" do
     before(:each) do 
          movie_1_attrs = FactoryGirl.attributes_for :movie
          movie_2_attrs = FactoryGirl.attributes_for :movie
          movie_3_attrs = FactoryGirl.attributes_for :movie
          movie_4_attrs = FactoryGirl.attributes_for :movie
          movie_5_attrs = FactoryGirl.attributes_for :movie
          
          movie_1_attrs["title"] = 'Star Wars'
          movie_1_attrs["rating"] = 'PG'
          movie_1_attrs["release_date"] = '1977-05-25'
          movie_1_attrs["director"] = 'George Lucas'
          movie_1_attrs["description"] = 'Star Wars is a movie about...'
          
          movie_2_attrs["title"] = 'Blade Runner'
          movie_2_attrs["rating"] = 'PG'
          movie_2_attrs["release_date"] = '1982-06-25'
          movie_2_attrs["director"] = 'Ridley Scott'
          movie_2_attrs["description"] = 'Blade Runner is a movie about...'

          movie_3_attrs["title"] = 'Alien'
          movie_3_attrs["rating"] = 'R'
          movie_3_attrs["release_date"] = '1979-05-25'
          movie_3_attrs["director"] = 'Ridley Scott'
          movie_3_attrs["description"] = '.........'

          movie_4_attrs["title"] = 'THX-1138'
          movie_4_attrs["rating"] = 'R'
          movie_4_attrs["release_date"] = '1971-03-11'
          movie_4_attrs["director"] = 'George Lucas'
          movie_4_attrs["description"] = 'THX is a movie about'
     
          movie_5_attrs["title"] = 'Superman'
          movie_5_attrs["rating"] = 'PG'
          movie_5_attrs["release_date"] = '1973-03-21'
          movie_5_attrs["director"] = ''
          movie_5_attrs["description"] = 'Superman is a movie about'
          
       
          @movie_1 = FactoryGirl.create(:movie, movie_1_attrs)
          @movie_2 = FactoryGirl.create(:movie, movie_2_attrs)
          @movie_3 = FactoryGirl.create(:movie, movie_3_attrs)
          @movie_4 = FactoryGirl.create(:movie, movie_4_attrs)
          @movie_5 = FactoryGirl.create(:movie, movie_5_attrs)
  end
    
    it "should find movies by the same director" do
      results = @movie_1.find_similar_by_director
      results.each do |movie|
          expect(movie.director).to eq(@movie_1.director)
      end
    end
    
    it "should not find movies by different directors" do 
      results = @movie_1.find_similar_by_director
      
      results.each do |movie|
          expect(movie.director).not_to eq(@movie_3[:director])
      end
    end
    
    it "should return an empty list when there is no director" do 
        results = @movie_5.find_similar_by_director
        expect(results).to eq([])
    end
  end # end of find_similar_by_director  describe block
  
  
  describe "#all_ratings" do
    
    it "should return all ratings" do
      expect(Movie.all_ratings).to match_array(['G', 'PG', 'PG-13', 'NC-17', 'R'])
    end

  end
  
end