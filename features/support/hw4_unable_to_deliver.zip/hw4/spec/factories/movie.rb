FactoryGirl.define do
    factory :movie do
        title "My Title"
        rating "R"
        description "My Movie is about a ..."
        release_date "1997-05-25"
        director "Lenovo"
    end
end