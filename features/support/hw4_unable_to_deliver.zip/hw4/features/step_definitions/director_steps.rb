Given /^the following movies exist:$/ do |table|
    table.hashes.each do |movie|
      Movie.create!(title: movie[:title], rating: movie[:rating], release_date: movie[:release_date], director: movie[:director])
  end
end

Then /^the director of "([^"]*)" should be "([^"]*)"$/ do |arg1, arg2|
  step %Q{I should see "#{arg1}"}
  step %Q{I should see "#{arg2}"}
end