# Add a declarative step here for populating the DB with movies.

Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    # each returned element will be a hash whose key is the table header.
    # you should arrange to add that movie to the database here.
    Movie.create(:title => movie["title"], :rating => movie["rating"], 
                  :released_date => movie["release_date"])
  end
  
end

# Make sure that one string (regexp) occurs before or after another one
#   on the same page

Then /I should see "(.*)" before "(.*)"/ do |e1, e2|
  first_movie = page.body.index(e1)
  second_movie = page.body.index(e2)
  first_movie < second_movie
end

# Make it easier to express checking or unchecking several boxes at once
#  "When I uncheck the following ratings: PG, G, R"
#  "When I check the following ratings: G"

When /I (un)?check the following ratings: (.*)/ do |uncheck, rating_list|
  # HINT: use String#split to split up the rating_list, then
  #   iterate over the ratings and reuse the "When I check..." or
  #   "When I uncheck..." steps in lines 89-95 of web_steps.rb
  rating_list.split(", ").each do |rating|
    if uncheck == "un"
      uncheck("ratings_" + rating)
    else
      check("ratings_" + rating)
    end
  end
end

Then /I should( not)? see the following movies:/ do |has_not, movie_list|
  movie_list.split(", ").each do |movie|
    if has_not == " not"
      if page.respond_to? :should
        page.should have_no_content(movie)
      else
        assert page.has_no_content?(movie)
      end
    else
      if page.respond_to? :should
        page.should have_content(movie)
      else
        assert page.has_content?(movie)
      end
    end
  end
end
  

Then /I should see all the movies/ do
  rows = page.all("table#movies tbody tr").count
  #expect(rows).to eq 10
  assert_equal 10, rows
end

Then /I should see none of the movies/ do 
  rows = page.all(:xpath, "//table[@id='movies']/tbody/tr").size
  assert_equal 0, rows
end