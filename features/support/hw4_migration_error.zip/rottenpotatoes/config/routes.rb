Rottenpotatoes::Application.routes.draw do
  
  root :to => 'movies#index' 
  
  resources :movies
  # map '/' to be a redirect to '/movies'
  match 'director/' => 'movies#same_director', :via => [:get]
  
  #root :to => redirect('/movies')
end
