require 'rails_helper'

RSpec.describe Movie, type: :model do
  describe "Same director" do
    before(:each) do
      @movie=double("Movie",id:55)
    end
    it "Calls Movie.where" do

      allow(Movie).to receive(:find).and_return(double("Movie",director:"Yo"))

      Movie.same_director(@movie)
    end
    it "Calls Movie.find" do
      allow(Movie).to receive(:find).and_return(double("Movie",director:"Yo"))
      expect(Movie).to receive(:find).with(55)
      Movie.same_director(@movie)
    end
    it "returns an array" do
      allow(Movie).to receive(:find).and_return(double("Movie",director:"Yo"))
      allow(Movie).to receive(:where).and_return({})
      expect(Movie.same_director(@movie).class).to eq Array
    end
  end
  describe "All Ratings" do
    it "returns an array" do
      expect(Movie.all_ratings.class).to eq Array
    end
  end
end