Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    Movie.create!(movie)
  end
end
Then(/^the (.*) of "([^"]*)" should be "([^"]*)"$/) do |attri, movie,val|

  expect(Movie.find_by_title(movie).send(attri)).to  eq(val)
end
