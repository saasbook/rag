class Movie < ActiveRecord::Base
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end
  
  def self.search_by_director(id)
    movie = Movie.find_by_id(id)
    if movie.director.nil? or movie.director.empty?
      return movie
    else
      # Movie.where("title != '%s' and director = '%s'", movie.title, movie.director).to_a
      Movie.where(director: movie.director).where("id != %s", movie.id)
      
    end
  end
end
