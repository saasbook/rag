require 'rails_helper'

describe Movie do
  describe 'searching movie list by director' do
    it 'finds movies by the same director' do
      movie1 = FactoryGirl.create(:movie, id: "1")
      movie2 = FactoryGirl.create(:movie, title: "Blade Runner", director: "Ridley Scott")
      movie3 = FactoryGirl.create(:movie, title: "Alien", director: "")
      movie4 = FactoryGirl.create(:movie, title: "THX-1138", director: "George Lucas")
      expect(Movie.search_by_director(movie1.id)).to eq([movie4])
    end
    
    it 'does not find movies by another director' do
      movie1 = FactoryGirl.create(:movie, id: "1")
      movie2 = FactoryGirl.create(:movie, title: "Blade Runner", director: "Ridley Scott")
      movie3 = FactoryGirl.create(:movie, title: "Alien", director: "")
      movie4 = FactoryGirl.create(:movie, title: "THX-1138", director: "George Lucas")
      expect(Movie.search_by_director(movie1.id)).to_not eq([movie2, movie3])
    end
  end
  
  describe 'searching when the director is nil or empty' do
    it 'should return the movie object' do
      movie = FactoryGirl.create(:movie, director: "")
      results = Movie.search_by_director(movie.id)
      expect(results).to eq movie
    end
  end
  
  describe 'calling the all_ratings method' do
    it 'should return an array' do
      results = Movie.all_ratings.class
      expect(results).to eq Array
    end
  end
  
end