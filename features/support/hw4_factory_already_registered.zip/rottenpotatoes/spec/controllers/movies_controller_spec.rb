require 'rails_helper'

describe MoviesController, type: :controller do
  describe 'Searching by directors' do
    before :each do
      @movie_class = class_double('Movie').as_stubbed_const
      @fake_results = [double('movie1'), double('movie2')]
    end
    
    it 'calls the model method that lists the movies by the same director' do
      expect(@movie_class).to receive(:search_by_director).with('1').and_return(@fake_results)
      get :search_directors, { :id => '1' }
    end
    
    describe 'after valid search' do
      
      before :each do
        allow(@movie_class).to receive(:search_by_director).with('1').and_return(@fake_results)
        get :search_directors, { :id => '1' }
      end
      
      it 'selects the results template for rendering' do
        expect(response).to render_template(:search_directors)
      end
      it 'makes the search results available to that template' do
        expect(assigns(:movies)).to eq @fake_results
      end
    end
    
  end
  
  describe 'the show controller method' do
    it 'should call the find method' do
      expect(Movie).to receive(:find)
      get :show, id: '1'
    end
  end
  
end