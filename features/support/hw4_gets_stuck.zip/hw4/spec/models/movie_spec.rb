require 'rails_helper'

describe Movie do
  describe 'find same director' do
    it 'should call same_director method in model' do
      Movie.should_receive(:same_director).with('Someone', '1')
      Movie.same_director('Someone', '1')
    end
  end
  describe 'find all ratings' do
    it 'should call all_ratings method in model' do
      Movie.should_receive(:all_ratings)
      Movie.all_ratings
    end
  end
end