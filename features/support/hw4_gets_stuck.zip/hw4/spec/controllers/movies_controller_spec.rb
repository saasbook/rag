require 'rails_helper'

describe MoviesController, type: :controller do
    describe 'CRUD' do
        before :each do
            @m1 = Movie.create!(:id => '1', :title => "Aladdin", :director => "Someone")
        end
        it 'should create a new movie with a flash' do
            post :create, {:movie => {:id => "2", :title => "Star Wars", :director => "Someone"}}
            response.should redirect_to(movies_path)
            flash[:notice].should_not be_blank
        end
        it 'should show the home screen of all the movies' do
            get :index
        end
        it 'should show the detail page of a certain movie' do
            get :show, :id => "1"
            expect(assigns(:movie)).to eq(@m1)
        end
        it 'should return the movie to be edited' do
            get :edit, :id => "1"
            expect(assigns(:movie)).to eq(@m1)
        end
        it 'should return the movie to be updated with a flash' do
            put :update, :id => "1", :movie => {:title => "Star Wars", :director => "Someone"}
            expect(assigns(:movie)).to eq(@m1)
            flash[:notice].should_not be_blank
            response.should redirect_to(movie_path(@m1))
        end
        it 'should delete the movie' do
            delete :destroy, :id => "1"
            response.should redirect_to(movies_path)
            flash[:notice].should_not be_blank
        end
    end
        
    
    describe 'GET #director' do
        context 'happy path' do
            before :each do
                @m1 = Movie.create!(:id => "1", :title => "Aladdin", :director => "Someone")
                @m2 = Movie.create!(:id => "2", :title => "Star Wars", :director => "Someone")
            end
            it 'should generate a RESTful route' do
                expect(:GET => director_movie_path(1)).to route_to(:controller => "movies", :action => "director", :id => "1")
            end
            it 'should call the model method to find movies with the same director' do
                @fake_results = [double('Movie'), double('Movie')]
                expect(Movie).to receive(:same_director).with('Someone', 1).and_return(@fake_results)
                get :director, :director => 'Someone', :id => '1'
            end
            it 'should render the director template with results' do
                get :director, :director => 'Someone', :id => '1'
                Movie.stub(:same_director).with('Someone', 1).and_return(@m2)
                response.should render_template("director")
                expect(assigns(:director_movies).first).to eq(@m2)
            end
        end
        
        context 'sad path' do
            before :each do
                @m1 = Movie.create!(:id => "1", :title => "Aladdin", :director => "Someone")
                @m2 = Movie.create!(:id => "2", :title => "Star Wars", :director => "SomeoneElse")
            end
            it 'should generate a RESTful route' do
                expect(:GET => director_movie_path(1)).to route_to(:controller => "movies", :action => "director", :id => "1")
            end
            it 'should render the index template with a flash' do
                get :director, :director => 'Someone', :id => '1'
                response.should redirect_to('/')
                flash[:notice].should_not be_blank
            end
        end
    end
end